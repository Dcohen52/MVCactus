import cgi
import http.server
import mimetypes
import os
import re
import socketserver
from Placeholdr.placeholdr import Placeholdr
import re
import datetime
import html

__version__ = "0.0.5"